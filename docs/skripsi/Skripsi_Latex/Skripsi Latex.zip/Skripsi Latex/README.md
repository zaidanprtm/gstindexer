Naskah Skripsi LaTeX
=============================

Template Naskah Skripsi dengan typesetting LaTeX untuk JTETI Universitas Gadjah Mada. Template ini merupakan hasil modifikasi dari versi pak Pekik Nurwantoro (FMIPA UGM) dan mas Yohan (JTETI UGM 2008).

Diedit dan digunakan untuk keperluan SKRIPSI SARJANA ILMU KOMPUTER.

Diunggah oleh:
Gregorius Andito Herjuno 
ILMU KOMPUTER 2013 
UNIVERSITAS NEGERI JAKARTA
3145136218